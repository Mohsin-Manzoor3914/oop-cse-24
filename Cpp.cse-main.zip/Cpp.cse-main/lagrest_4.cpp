#include<iostream>
using namespace std;
int main(){
    int a,b,c,d;
cout<<"enter 4 numbers";
cin>>a>>b>>c>>d;
int greatest=a ;
if (b>greatest)
greatest=b;
 if (c>greatest)
greatest=c;
if(d>greatest)
greatest=d;
cout<<"greatest number is:  "<<greatest;

}















